package utils

import "time"

var GetNow = func() time.Time {
	return time.Now()
}
